/**
    Algorithms and Data Structures
    Homework 11
    Shortest Paths
    Huzaifa Hashim
    Done in collaboration with Arsenij, Jordan Streete and Lucia Fuentes
**/

#include <iostream>
#include <vector>
#include <cstdlib>

using namespace std;

class PuzzleBoard {
private:
    int dimension; //dimension
    int **ptr;    //two dimensional matrix to stores vertices
    int x, y;    //coordinates(x, y) on a graph

public:
    PuzzleBoard(int dimension, int** ptr)
    {
        this -> dimension = dimension;
        this -> ptr = ptr;
        this -> x = 0;
        this -> y = 0;
        ///(0, 0) refers to the top left of the puzzle
    }

    ///makes moves in juxtaposition to current location
    ///and checks correct possible ways to move in 4 directions
    bool makeMoves(int direction)
    {
        int curr = ptr[x][y];
        switch(direction)
        {
            case 0:
                if(x - curr >= 0)
                    return 1;
                else
                    return 0;

            case 1:
                if(y + curr < dimension)
                    return 1;
                else
                    return 0;

            case 2:
                if(x + curr < dimension)
                    return 1;
                else
                    return 0;

            case 3:
                if(y - curr >= 0)
                    return 1;
                else
                    return 0;

            default:
                return 0;
        }
    }

    ///result can only be valid if position is at
    ///bottom right which will be when (x, y) == (dimension - 1, dimension - 1)
    bool getResult()
    {
        if(x == dimension - 1 && y == dimension - 1)
            return 1;
        else
            return 0;
    }

    ///overloading operator << to produce output
    friend ostream& operator<<(ostream &, const PuzzleBoard  &);
    /**
        this implementation is a part of the algorithm for
        the minimum number of moves to solve the prob - part c of question
        the logic of this algorithm is to initialize it to the top left box (0, 0)
        and then push values of the box into vectors, for x and for y. With a series of
        if statements and static arrays that are a precursor from the boolMakemove function
        it creates small incremental values to change the coordinates in accordance by multiplication.
        This ensures movement only in one direction at a time. When this movement brings us to the coordinate that
        correspond with (dimension - 1) as both x and y coordinate, you can declare the objective complete and return the
        amount of cells to traverse, or what have you.
        Note this logic is the result of talking to peers from the class and looking at a static implementation from
        geeksforgeeks.org which is done using 2 two dimensional arrays, instead of a vector.
    **/

    int solve()
    {
        //store minimum number of cells to traverse to reach bottom right
        int minPath[this -> dimension][this -> dimension];
        for(int i = 0; i < this -> dimension; i++)
        {
            for(int j = 0; j < this -> dimension; j++)
                minPath[i][j] = INT32_MAX;
        }

        ///base case
        minPath[0][0] = 0;

        vector <int> x1;
        x1.push_back(0);
        vector <int> y1;
        y1.push_back(0);

        int x2[4] = {-1, 0, 1, 0};
        int y2[4] = {0, 1, 0, 1};

        while(!x1.empty())
        {
            int x3 = x1.back();
            int y3 = y1.back();

            x1.pop_back();
            y1.pop_back();

            for(int i = 0; i < 4; i++)
            {
                int x4 = x3 + (x2[i] * this -> ptr[x3][y3]);
                int y4 = y3 + (y2[i] * this -> ptr[x3][y3]);

                    if(x4 >= 0 && x4 < this -> dimension && y4 >= 0 && y4 < this -> dimension)
                    {
                        if(minPath[x3][y3] + 1 < minPath[x4][y4])
                        {
                            minPath[x4][y4] = minPath[x3][y3] + 1;
                            x1.push_back(x4);
                            y1.push_back(y4);
                        }
                    }
            }
        }

            if(minPath[this -> dimension - 1][this -> dimension - 1] != INT32_MAX)
            {
                cout << "The number of nodes visited to reach the bottom right of the grid";
                return minPath[this -> dimension - 1][this -> dimension - 1];
            }

            else
                cout << "There does not exist a path to the bottom left of the entered grid!\n";
        };
};

    ostream& operator<<(ostream& os, const PuzzleBoard &m)
    {
        for(int i = 0; i < m.dimension; i++)
        {
            for(int j = 0; j < m.dimension; j++)
                os << m.ptr[i][j]<<" ";

            os << endl;
        }

        return os;
    }


int main()
{
    int n;
    cout << "Enter Dimensions for a n*n grid\n";
    cin >> n;

    int **mat = new int*[n];
    for(int i = 0; i < n; i++)
        mat[i] = new int[n];

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
            cin >> mat[i][j];
    }

    PuzzleBoard grid(n,mat);
    cout << grid.solve() << endl;

}
