import numpy as np
from copy import deepcopy as copy

#code created by lucia fuentes,huzaifa hashim , Jordan Streete
#code bases/inspired on https://www.programcreek.com/2014/07/leetcode-best-meeting-point-java/
###creates matrix with 0 as diagonal, to represemt distance is 0 to same city . x is number of cities
def Matrix(x): 
    mat = np.random.randint(1,60,(x,x))
  
    mat += mat.T
    #transposing to make it symetic
    for y in range(x):
        mat[y][y] = 0
     #adding 0s   
    return mat


def find(mat,c,d):
    posDist = [] #possible meeting cities
    #prints matrix
    print(mat)
    #appends max value
    for x in range(len(mat)):
        posDist.append(max(mat[c][x], mat[d][x])) 
    
    #returs index with total value minimal
    result = 0
    for y in range(len(posDist)):
        if posDist[result] > posDist[y]:
            result = y
    return result

test = Matrix(10)
c1 = 5
c2 = 8
print(find(test, 2, 5) )
