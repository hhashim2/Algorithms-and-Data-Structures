/**
    Algorithms and Data Structures
    Homework 11
    Shortest Paths
    Huzaifa Hashim
    Done in collaboration with Jordan Streete and Lucia Fuentes
**/

#include <iostream>
#include <cstdlib>

class PuzzleBoard {
private:
    int dimension; //boardsize
    int **ptr;    //two dimensional matrix to stores vertices
    int x, y;    //coordinates(x, y) on a graph

public:
    PuzzleBoard(int dimension, int** ptr)
    {
        this -> dimension = dimension;
        this -> ptr = ptr;
        this -> x = 0;
        this -> y = 0;
        ///(0, 0) refers to the top left of the puzzle
    }

    ///makes moves in juxtaposition to current location
    ///and checks correct possible ways to move in 4 directions
    bool makeMoves(int direction)
    {
        int curr = ptr[x][y];
        switch(direction)
        {
            case 0:
                if(x - curr >= 0)
                    return 1;
                else
                    return 0;

            case 1:
                if(y + curr < dimension)
                    return 1;
                else
                    return 0;

            case 2:
                if(x + curr < dimension)
                    return 1;
                else
                    return 0;

            case 3:
                if(y - step >= 0)
                    return 1;
                else
                    return 0;

            default:
                return 0;
        }
    }

    ///result can only be valid if position is at
    ///bottom right which will be when (x, y) == (dimension - 1, dimension - 1)
    bool getResult()
    {
        if(x == dimension - 1 && y == dimension - 1)
            return 1;
        else
            return 0;
    }

    ///overloading operator << to produce output
    std::ostream &operator<<(std::ostream &os, PuzzleBoard const &m)
    {
        for(int i = 0; i < m.dimension; i++)
        {
            for(int j = 0; j < m.dimension; j++)
                os << m.ptr[i][j] << " ";
        }

        return os;
    }

    ///this implementation is a part of the algorithm for
    ///the minimum number of moves to solve the prob - part c of question
    ///check file minCost.cpp
    int solve()
    {
        ...
        ..
        .
    }
};



