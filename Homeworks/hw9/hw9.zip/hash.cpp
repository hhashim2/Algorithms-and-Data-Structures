/**
    Algorithms and Data Structures
    Homework 9
    Huzaifa Hashim
    Hash Function implementation
    Worked with Jordan Streete and Lucia Fuentes
**/

#include <iostream>
using namespace std;
// code referenced from:
//www.geeksforgeeks.org/implementing-hash-table-open-addressing-linear-probing-cpp/

class Node{
public:
    int key;
    int value;
    Node(int key, int value){
        this->key = key;
        this->value = value;
    }
};


class HashTable{
    Node **arr; //hash elements array double pointer, as it contains key and value
    int maxSize; //maximum capacity
    int currentSize; //number of current elements
    //dummy node
    Node *dummy;
public:
    HashTable(){
        maxSize = 20; //initial capacity hash array
        currentSize = 0;
        arr = new Node*[maxSize];

        //Initialise array
        for(int x = 0 ; x < maxSize ; x++){
            arr[x] = nullptr;
        }

        dummy = new Node(-1, -1); //dummy with value, key = -1
    }

    int hashCode(int key){ //hash function to find index number of array for key
        return key % maxSize;
    }

    void insertNode(int key, int value){ //adds key and value to arr
        Node *t = new Node(key, value);

        int newIndex = hashCode(key); //applies hash function to find index

        while(arr[newIndex] != nullptr && arr[newIndex]->key != key
              && arr[newIndex]->key != -1){ //find free space
               newIndex++;
                newIndex %= maxSize;
        }

        if(arr[newIndex] == nullptr || arr[newIndex]->key == -1){
            currentSize++;
        }
        arr[newIndex] = t;
    }



    int get(int key){ //return value at given key

        int newIndex = hashCode(key); //apply hash fucntion
        int count = 0;
        while(arr[newIndex] != nullptr){ //finding node with such key
            count = 0;
            if(count++ >maxSize ){  //if counter goes avobe capacity
                return 0;
            }
            if(arr[newIndex]->key == key){ //if node found
                return arr[newIndex]->value;
            }
            newIndex++;
            newIndex %= maxSize;
        }


        return 0;
    }


    //Return true if size is 0
    bool isEmpty(){
        bool returnval = (currentSize == 0);
        return returnval;;
    }

};

//Driver method to test map class
int main()
{
    HashTable *ht = new HashTable;
    ht -> insertNode(1,1);
    ht -> insertNode(2,2);
    ht -> insertNode(2,3);


    cout << ht->isEmpty() << endl;
    cout << ht->get(1)<< endl;;
    cout << ht->get(2)<< endl;;

    return 0;
}
