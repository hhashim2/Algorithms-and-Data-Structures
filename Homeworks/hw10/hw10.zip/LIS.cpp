/**
    Algorithms and Data Structures
    Homework 10
    Dynamic Programming
    Problem 10.1 Longest Common Subsequence
    Huzaifa Hashim
**/

#include <iostream>
#include <cstdlib>

void printArray(int *arr, int *result, int x)
{
    //base case
    if(x < 0)
        return;

    //recursively calls until condition is false
    if(result[x] != -1)
        printArray(arr, result, result[x]);

    std::cout << arr[x] << " ";
}

int main()
{
    int x;
    std::cout << "Enter size of array = ";
    std::cin >> x;
    std::cin.get();

    //the I/O on the question wants user defined input, the only difference in my program
    //is that it also asks for the length of the array to allocate memory
    int* arr = new int(x);

        for (int i = 0; i < x; i++)
        {
            std::cout << "Enter number: ";
            std::cin >> arr[i];
            std::cin.get();
        }

    //use of two arrays to make sure that the values of the last index is stored
    //which is then used to return the actual values of the sequence
    int *temp;
    int *output;

    int max = x > 0 ? 1 :0;
    int n, max1, i, j;

    temp = (int*)malloc(sizeof(int) * x);
    output = (int*)malloc(sizeof(int) * x);

    for(i = 0; i < x; i++)
    {
        temp[i] = 1;
        output[i] = -1;
    }

    // Compute the Longest Increasing Sequence in bottom up manner
    //computes the actual values of the sequence rather than returning just the
    //length of the sequence
    for(i = 1; i < x; i++)
    {
        n = temp[i];
        for(j = 0; j < i; j++)
        {
            if((arr[i]) > arr[j] && (temp[j] >= n))
            {
                n = temp[j] + 1;
                output[i] = j;
            }
        }

        //stores the actual subsequence in output array
        temp[i] = n;
        if(n > max)
        {
            max1 = i;
            max = n;
        }
    }

    std::cout << "The longest increasing subsequence is "<< max << std::endl;
    printArray(arr, output, max1);
    std::cout << "\n";
    return 0;
}
