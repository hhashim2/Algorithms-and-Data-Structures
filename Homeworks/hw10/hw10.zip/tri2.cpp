/**
    Algorithms and Data Structures
    Homework 10
    Maximum Path Sum of a Triangle
    Huzaifa Hashim
**/

/**
    Analysis and Comparison with Brute Force Algorithm
    The Brute Force implementation compares every possible path. This number
    will grow exponentially leading to an algorithm that might be great for smaller
    numbers but for larger rows it would be terrible. Considering that the rows can
    increase to 100, the run time of the worst case would be:
    (2^rows - 1) = 2^99 = 6.338*10^29
    Thus, this algorithm's run time in asymptotic notation would be something like this:
    O(2^n-1)

    The dynamic programming algorithm would be co-related to the two nested for loops
    that places the index at the second last row and then iteratively sums the numbers.
    Run time = O(n^2)
**/

#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main()
{
    vector <int> triangle;
    int x;

    //input for number of rows
    cout << "Enter number of rows = ";
    cin >> x;

    //calculation of the number of elements to be added inside the vector
        for(int i = 0; i < (x *(x + 1)) / 2; ++i)
        {
            int current;
            cin >> current;
            triangle.push_back(current);
        }

    //This loop starts the bottom up approach, starting from the second to last row
    //and summing the two possible children of every node and choosing the larger of the two
    //and then iterating to the row above
    //This iterative process ends with the maximum path sum at the 0th index of the vector
    //when it terminates

    for(int i = x - 1; i > 0; --i)
        for(int j = (i * (i - 1)) / 2; j < (i * (i + 2)) / 2; ++j)
            triangle[j] += max(triangle[j + i], triangle[j + i + 1]);

    cout << "Maximum Sum = " << triangle[0] << endl;
    return 0;
}


/**
    A greedy algorithm cannot work for this problem for the following reason:
    The greedy algorithm runs with the assumption that a locally optimal choice is
    also globally optimal. However, a locally optimal decision in a tree that resembles
    a triangle won't necessarily be the globally optimal solution. If the algorithm traverses
    from the bottom, it would pick 6 as larger than 5 and move upwards accordingly. Even though this is
    a locally optimal solution, the end sum shall not equal to the maximum possible sum.

    This problem exhibits the hallmark for Dynamic Programming, i.e. it has the optimal
    substructure, however, it does not necessarily go ahead and meet the hallmark for
    Greedy Algorithms like for instance the Minimum Spanning Tree problem does.

**/
