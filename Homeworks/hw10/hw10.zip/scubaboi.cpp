/**
    Algorithms and Data Structures
    Homework 10
    Dynamic Programming
    Problem 10.3 Scuba Diver
    Huzaifa Hashim - In conjunction with Lucia Fuentes, and Jordan Streete
    Referenced from https://stackoverflow.com/questions/6849569/dynamic-programming-spoj-problem-scubadiv
**/

#include <iostream>
#include <cstdlib>
#include <algorithm>

//global variables for ease
const int MAX = 800;
const int err = 99999;
int oxygen[22], nitrogen[80], w[MAX];
int mat[MAX][22][80];

int computeComb(int x, int volOx, int volNit)
{
    //checks for conditions on the specification of the cylinder
    if(mat[x][volOx][volNit] != -1)
        return mat[x][volOx][volNit];

    if(volOx == 0 && volNit == 0)
        mat[x][volOx][volNit] = 0;

    //This condition handles the case when it is not possible to
    //meet the desired volume. This is handled by terminating paths to
    //this condition
    else if(x == 0)
        mat[x][volOx][volNit] = err;

    //selects ith cylinder or iterates to i - 1th cylinder for oxygen and nitrogen
    else
        mat[x][volOx][volNit] = std::min(computeComb(x - 1, volOx, volNit),
                                         computeComb(x - 1, std::max(volOx - oxygen[x - 1], 0),
                                                     std::max(volNit - nitrogen[x - 1], 0)) + w[x - 1]);

    return mat[x][volOx][volNit];
}

int main()
{
    int N, O, numCylinder, numCases, i, j, k;
    std::cout << "Enter number of test cases.\n";
    std::cin >> numCases;

    while(numCases--)
    {
        std::cout << "Enter required liters of Oxygen and Nitrogen.\n";
        scanf("%d %d", &O, &N);
            std::cout << "volume of oxygen exceeds limit\n";

        std::cout << "Enter number of cylinders available to diver.\n";
        scanf("%d", &numCylinder);

        //this nested series of for loops distinguishes between the cylinders to use
        for(i = 0; i < numCylinder + 1; i++)
            for(j = 0; j < O + 1; j++)
                for(k = 0; k < N + 1; k++)
                    mat[i][j][k] = -1;

        //this shall compute the minimum weight that will satisfy the combination of oxygen
        //and nitrogen desired by the diver
        for(int i = 0; i < numCylinder; i++)
        {
            std::cout << "Enter cylinder specifications.\n";
            scanf("%d %d %d", &oxygen[i], &nitrogen[i], &w[i]);
        }

        std::cout << "Minimum weight diver can carry = " << computeComb(numCylinder, O, N) << std::endl;
        //std::cout << "Cylinder Index = " <<
    }

    return 0;
}
