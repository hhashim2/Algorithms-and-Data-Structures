//12.2--b
//  hw12
//LUCIA FUENTES
//MADE IN COOPERATION WITH Huzaifa Hashim and Jordan Streete

#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;

// d is the number of characters in the input alphabet
#define d 256


void search(char lookfor[], char base[], int prime){
    int XX = strlen(lookfor);
    int YY = strlen(base);
    int i, j;
    int s = 0; //value for string to look for
    int b = 0; // value for base text
    int h = 1;


    for (i = 0; i < XX - 1; i++){
        h = (h * d) % prime;
    }
    // Calculate the hash value of pattern

    for (i = 0; i < XX; i++){
        s = (d * s + lookfor[i]) % prime; //s becomes hash value for lookfor
        b = (d * b + base[i]) % prime; //b become shsh value for bas etext
    }

    // Slide the string to lookk fthrough text, char by char
    for (i = 0; i <= YY - XX; i++){


        if ( s == b ){ //if hasdh value matches then it checks for chars one by one

            for (j = 0; j < XX; j++){
                if (base[i+j] != lookfor[j]) //checks chars one by one
                    break;
            }

            if (j == XX){
                cout<<"Found at index "<< i<<endl;
            }
        }


        if ( i < YY-XX){
            b = (d*(b - base[i]*h) + base[i+XX])%prime;

            if (b < 0){
                b = (b + prime);
            }
        }
    }
}

int main(){
    char base[] = "JAJJAJAJJAJJA, ME CAGAN TODOS ACA ALV";
    char look[] = "ALV";
    int pri = 41; // prime for function which is greater or equal to |s|
    search(look, base, pri);
    return 0;
}

