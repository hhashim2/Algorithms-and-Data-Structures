/**
    Algorithms and Data Structures
    N Knights Problem
    Huzaifa Hashim
    Homework 12
    referenced from geeksforgeeks
    comments and a description included
**/

#include <iostream>
using namespace std;

//global variables stores the only input and the number of possible solutions
int m;
int count = 0;

void makeBoard(char** board)
{
	for (int i = 0; i < m; i++)
    {
		for (int j = 0; j < m; j++)
			board[i][j] = '_';

	}
}

void displayBoard(char** board)
{
    cout << endl << endl;
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cout << " " << board[i][j] << " ";
        }
        cout << endl;
    }
}

/* This function marks all the attacking
position of a knight placed at board[i][j]
position */
void attack(int i, int j, char a,
			char** board)
{

    //attack function prints char a on squares that can be attacked by
    //an already placed knight
	/* conditions to ensure that the
	block to be checked is inside the board */
	if ((i + 2) < m && (j - 1) >= 0) {
		board[i + 2][j - 1] = a;
	}
	if ((i - 2) >= 0 && (j - 1) >= 0) {
		board[i - 2][j - 1] = a;
	}
	if ((i + 2) < m && (j + 1) < m) {
		board[i + 2][j + 1] = a;
	}
	if ((i - 2) >= 0 && (j + 1) < m) {
		board[i - 2][j + 1] = a;
	}
	if ((i + 1) < m && (j + 2) < m) {
		board[i + 1][j + 2] = a;
	}
	if ((i - 1) >= 0 && (j + 2) < m) {
		board[i - 1][j + 2] = a;
	}
	if ((i + 1) < m && (j - 2) >= 0) {
		board[i + 1][j - 2] = a;
	}
	if ((i - 1) >= 0 && (j - 2) >= 0) {
		board[i - 1][j - 2] = a;
	}
}

//checks all places that can be filled with knights
bool canPlace(int i, int j, char** board)
{
	if (board[i][j] == '_')
		return true;
	else
		return false;
}

//uses a new board configuration to print all solutions recursively
//calls function until no new configuration possible
//places knights at [i][j] of two dimensional matrix
void place(int i, int j, char k, char a,
		char** board, char** new_board)
{

	/* Copy the configurations of
	old board to new board */
	for (int y = 0; y < m; y++)
    {
		for (int z = 0; z < m; z++)
			new_board[y][z] = board[y][z];
	}

	/* Place the knight at [i][j]
	position on new board */
	new_board[i][j] = k;

	/* Mark all the attacking positions
	on all knights on the new board */
	attack(i, j, a, new_board);
}

//function that checks where it's safe to place a knight
void nKnights(int k, int sti, int stj, char** board)
{

	//terminating condition
	if (k == 0)
    {
		displayBoard(board);
		count++;
	}

	else
    {
        for (int i = sti; i < m; i++)
        {
			for (int j = stj; j < m; j++)
            {
				if (canPlace(i, j, board))
                {
					/* Create a a new board and place the
					new knight on it */
					char** new_board = new char*[m];
					for (int x = 0; x < m; x++)
						new_board[x] = new char[m];

					place(i, j, 'K', 'X', board, new_board);

                    //recursion to print all possible solutions until terminating condition
					nKnights(k - 1, i, j, new_board);

					//freeing memory
					for (int x = 0; x < m; x++)
						delete[] new_board[x];

					delete[] new_board;
				}
			}
			stj = 0;
		}
	}
}

// Driver code
int main()
{
	cout << "Enter dimension and number of knights = ";
	cin >> m;

	/* Creation of a m*m board */
	char** board = new char*[m];
	for (int i = 0; i < m; i++)
        board[i] = new char[m];

    //initialize all values
	makeBoard(board);

	//check conditions and print
	nKnights(m, 0, 0, board);

	cout << "\nTotal number of solutions = "	<< count;
	return 0;
}



/**
    Description of code!
    The idea of backtracking emerges from problems that have solutions which grow in increments.
    Similarly, the idea behind this algorithm was very intuitive after the N Queens problem in the lecture.
    We first initially start at (0, 0) and then move on through rows to fill it up. The initial idea that will not
    print all solutions is to think that if a chessboard has black and white squares, a knight will never be able to attack
    a white square if it is in a black square. However, to solve all solutions you write a function that follows all the attacking
    technique of a knight in the standard game of chess. The way that is implemented is by always calling this function after placing a knight
    to mark all the positions it can possible attack. This way we ensure that another knight that will be won't be attacked by a knight already on the board.
    This idea is shown by this algorithm by placing X on all places that can be attacked, and the places with _ are still places you can place the knights at.
    The idea of backtracking comes in that whenever a new knight is put on the board, a new board is also created consequently we can backtrack to check
    other possible places that can be placed with knight and then have another form an already existing solution. So in ways, we rely on our previous board
    to form a new board which is shown by the similarity in subsequent boards that are printed. This continues until this idea is completely exhausted and
    gives us all possible ways n knights can be placed on a n*n chessboard

    Considering this is also the last homework, I would like to thank all the TA's for your support and help through the homeworks. I hope you do
    great in the life that is ahead if you're graduating. The world is a better place because of you!!!!
**/
